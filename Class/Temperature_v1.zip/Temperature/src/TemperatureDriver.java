public class TemperatureDriver {
    
    public static void main(String[] args) {
        Temperature testA = new Temperature();
        System.out.println("The default for testA is "+testA.toString());
        
        if(testA.setValue(303.13F)==true)
            System.out.println("After setting value, testA is "+testA.toString());
        else
            System.out.println("Out of Range");
        
        if(testA.setType('F')==true)
            System.out.println("After setting value, testA is "+testA.toString());
        else
            System.out.println("Out of Range");
        
        if(testA.setValue(-503.25F)==true)
            System.out.println("After setting value, testA is "+testA.toString());
        else
            System.out.println("Out of Range");
    }
    
}
