public class Temperature {
    
    //Member Variables
    private float value = 0;
    private char type = 'K';

    /**
     * @return the value
     */
    public float getValue() {
        return value;
    }

    /**
     * @param new_value the value to set
     */
    public boolean setValue(float new_value) {
        if ( type == 'K' || type=='k' ){
            if (new_value >= 0){
                value=new_value;
                return true;
            }
            else
                return false;
        }
        else if( type == 'F' || type=='f' ){
            if (new_value >= -459.4){
                value=new_value;
                return true;
            }
            else
                return false;
        }
        else if( type == 'C' || type=='c' ){
            if (new_value >= -273.13){
                value=new_value;
                return true;
            }
            else
                return false;
        }
        else
            return false; //if not K, F, or C
        
    }

    /**
     * @return the type
     */
    public char getType() {
        return type;
    }

    /**
     * @param new_type the type to set
     */
    public boolean setType(char new_type) {
        if ( new_type == 'K' || new_type=='k' ){
            type=new_type;
        }
        else if( new_type == 'F' || new_type=='f' ){
            type=new_type;
        }
        else if( new_type == 'C' || new_type=='c' ){
            type=new_type;
        }
        else
            return false; //if not K, F, or C
        return true;
    }
    
    @Override
    public String toString(){
        return String.format("%.2f%c",value,type);
    }
    
    
}
