package bjd;

import java.util.Scanner;

public class Monthly_Sales_Tax {

    public static void main(String[] args) {
        // declare integer variables
        String month;
        int year;
        float totSale,sales,csTax,stTax,ttsTax;
        
        // create scanner object called keyboard to read in characters user types
        Scanner keybrd = new Scanner(System.in);
        
        // promt the user to enter a value for value1
        System.out.print("Enter the month:");
        month = keybrd.next();
        
        System.out.print("Enter the year:");
        year = keybrd.nextInt();
        
        System.out.print("Enter the total sales:");
        totSale = keybrd.nextFloat();
        
        //Computations
        sales = totSale/1.0920f;
        csTax = sales*.0145f;
        stTax = sales*.0775f;
        ttsTax = sales*.0920f;
        
        // output our results using println
        System.out.println("Month: "+month+" "+year);
        System.out.println("-------------------------------");
        System.out.printf("Total Collected:     $%9.2f%n",totSale);
        System.out.printf("Sales:               $%9.2f%n",sales);
        System.out.printf("County Sales Tax:    $%9.2f%n",csTax);
        System.out.printf("State Sales Tax:     $%9.2f%n",stTax);
        System.out.printf("Total Sales Tax:     $%9.2f%n",ttsTax);
        
    }
    
}
