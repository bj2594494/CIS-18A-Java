package bdj;

import java.util.Scanner;

public class Max_Min {

    public static void main(String[] args) {
        // declare integer variables
        int value1, value2, value3, value4, max, min;
        max=min=0;
                
        // create scanner object called keyboard to read in characters user types
        Scanner keybrd = new Scanner(System.in);
        
        // promt the user to enter a value for value1
        System.out.print("Enter the first value: ");
        value1 = keybrd.nextInt();
        
        // promt the user to enter a value for value2
        System.out.print("Enter the second value: ");
        value2 = keybrd.nextInt();
        
        // promt the user to enter a value for value1
        System.out.print("Enter the third value: ");
        value3 = keybrd.nextInt();
        
        // promt the user to enter a value for value2
        System.out.print("Enter the fourth value: ");
        value4 = keybrd.nextInt();
        
        //getting max
        if((value1>value2)&&(value1>value3)&&(value1>value4)){
            max=value1;
        }
        else if((value2>value1)&&(value2>value3)&&(value2>value4)){
            max=value2;
        }
        else if((value3>value2)&&(value3>value1)&&(value3>value4)){
            max=value3;
        }
        else if((value4>value2)&&(value4>value3)&&(value4>value1)){
            max=value4;
        }
        
        //getting min
        if((value1<value2)&&(value1<value3)&&(value1<value4)){
            min=value1;
        }
        else if((value2<value1)&&(value2<value3)&&(value2<value4)){
            min=value2;
        }
        else if((value3<value2)&&(value3<value1)&&(value3<value4)){
            min=value3;
        }
        else if((value4<value2)&&(value4<value3)&&(value4<value1)){
            min=value4;
        }
        
        //displaying output
        System.out.printf("The values entered: %d,%d,%d,%d have a minimum value "
                + "%d and maximum value %d%n", value1, value2, value3, value4, min, max);
        
    }
    
}
