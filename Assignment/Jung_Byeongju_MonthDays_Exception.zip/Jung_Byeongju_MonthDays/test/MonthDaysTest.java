import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class MonthDaysTest {
    
    public MonthDaysTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    @Test
    public void testMonth() {
        int month=5;
        int year=1995;
        MonthDays instance = new MonthDays(month,year);
        try{
            instance.setMonth(13);
        }
        catch(IllegalArgumentException e){
            System.out.println("Month must be between 1 and 12. Program terminating.");
        }     
    }
    
    @Test
    public void testYear() {
        int month=5;
        int year=1995;
        MonthDays instance = new MonthDays(month,year);
        try{
            instance.setYears(-1);
        }
        catch(IllegalArgumentException e){
            System.out.println("Month must be between 1 and 12. Program terminating.");
        }     
    }
}
