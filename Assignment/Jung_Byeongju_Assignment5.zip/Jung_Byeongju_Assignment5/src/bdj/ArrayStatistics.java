package bdj;

import java.util.Scanner;

public class ArrayStatistics {
    
    public static double popSD(double... v){
        double sum, average, dist, sumDist, popStan;
        int counter=0;
        sum = sumDist = dist = 0;
        for(double e:v) {
            sum += e;
            counter++;
        }
        average=sum/counter;
        for(double e:v) {
            dist = Math.pow((e-average), 2);
            sumDist += dist;
        }
        popStan = Math.sqrt((sumDist/counter));
        return popStan;
    }
    
    public static double samSD(double... v){
        double sum, average, dist, sumDist, samStan;
        int counter=0;
        sum = sumDist = dist = 0;
        for(double e:v) {
            sum += e;
            counter++;
        }
        average=sum/counter;
        for(double e:v) {
            dist = Math.pow((e-average), 2);
            sumDist += dist;
        }
        samStan = Math.sqrt((sumDist/(counter-1)));
        return samStan;
    }
    
    public static void main(String[] args) {
        int num;
        double sum ,average, popStan, samStan, min, max;
        sum  = 0;
        
        System.out.print("How many number of the type double do you want to store in your array? ");
        num = new Scanner(System.in).nextInt();
        
        double doubleArray[];
        doubleArray = new double[num];
        
        for(int i=0;i<num;i++){
            System.out.print("Enter a value #"+(i+1)+": ");
            doubleArray[i] = new Scanner(System.in).nextDouble();
            sum+=doubleArray[i];
        }
        max=doubleArray[0];
        min=doubleArray[0];
        for(int i=0;i<num;i++){
            if(doubleArray[i]>max) max = doubleArray[i];
            if(doubleArray[i]<min) min = doubleArray[i];
        }
        
        average = sum / num;
        
        popStan = popSD(doubleArray);
        samStan = samSD(doubleArray);
        
        System.out.println("");
        System.out.println("The statistics for your user entered array is:");
        System.out.println("-----------------------------------------------");
        System.out.println("");
        System.out.printf("                        Minimum:%11.3f%n", min);
        System.out.printf("                        Maximum:%11.3f%n", max);
        System.out.printf("                        Average:%11.3f%n", average);
        System.out.printf("Standard deviation (population):%11.3f%n", popStan);
        System.out.printf("    Standard deviation (sample):%11.3f%n", samStan);
    }
    
}
