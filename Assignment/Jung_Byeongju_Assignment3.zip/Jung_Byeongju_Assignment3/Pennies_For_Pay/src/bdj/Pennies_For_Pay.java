package bdj;

import java.util.Scanner;

public class Pennies_For_Pay {

    public static void main(String[] args) {
        Scanner kbd = new Scanner(System.in);
        double pay=.01;
        double totPay=0;
        
        System.out.println("For how many days will the pay double?");
        System.out.println("Enter Days Greater Than 0 and Less Than 46");
        double x = kbd.nextInt();
        while(x<1||x>45){
            System.out.println("Invalid Entry! Please Try Again.");
            System.out.println("For how many days will the pay double?");
            System.out.println("Enter Days Greater Than 0 and Less Than 46");
            x = kbd.nextInt();
        }
        
        System.out.println();
        System.out.println("Day             Total Pay");
        System.out.println("---------------------------------");
        
        for(int i=0;i<x;i++){
            if(i<9){
                System.out.printf("%d               $%15.2f%n",i+1,pay);
            }
            else if(i>=9){
                System.out.printf("%d              $%15.2f%n",i+1,pay);
            }
            totPay+=pay;
            pay*=2;
        }
        System.out.println("---------------------------------");
        System.out.printf("Total           $%15.2f%n",totPay);
    }
    
}
