import java.util.Scanner;

public class MonthDaysDriver {

    
    public static void main(String[] args) {
        MonthDays date = new MonthDays();
        Scanner keybrd = new Scanner(System.in);
        System.out.print("Enter the month (1=January, 2=February, ..., 12=December): ");
        date.setMonth(keybrd.nextInt());
        System.out.print("Enter the year: ");
        date.setYears(keybrd.nextInt());
        System.out.println();
        System.out.println(date.getMonth()+"/"+date.getYears()+" has "+date.getNumberOfDays()+" days.");
    }
    
}
